#电荷在均匀电场中运动的动态模拟
import numpy as np
import matplotlib.pyplot as plt
import os
import math
import time
import tkinter as tk
from tkinter import *  #用于小界面的设置
#

#观测参数
observation_max=10000
#物理学参数
k=8.9   #*(10**9)
#点电荷定义
class  electron:
    def __init__(self,x,y,m,q,v_x,v_y):
        self.x=[x]
        self.y=[y]
        self.q=q
        self.m=m
        self.t=0
        self.dt=0.5
        self.v_x=v_x
        self.v_y=v_y
    def situation(self,E_x,E_y):
        #参数为电场强度，可变可调，方向默认向下为正
        a_x=E_x*self.q/self.m
        a_y=E_y*self.q/self.m
        v_x=self.v_x+a_x*self.dt
        v_y=self.v_y+a_y*self.dt
        x1=self.x[-1]+self.v_x*self.dt+0.5*a_x*((self.dt)**2 )   # 物体的水平位置
        y1=self.y[-1]+self.v_y*self.dt+0.5*a_y*((self.dt)**2 )   # 物体的垂直位置

        self.v_x=v_x
        self.v_y=v_y
        self.t=self.t+0.5
        (self.x).append(x1)  # 记录轨迹
        (self.y).append(y1)  # 记录轨迹

    def renewxy(self):
        #当运动超过一定距离开始清除尾迹
        if len(self.x)>100:
            del self.x[0]
            del self.y[0]
    def renewall(self):
        #一键清除所有尾迹
        if len(self.x)>10:
            del self.x[0:len(self.x)-10]
            del self.y[0:len(self.y)-10]

class  E:
    def __init__(self,Ex,Ey):
        self.Ex=Ex
        self.Ey=Ey

plt.ion()  # 开启交互模式
running=False
renewyes=True

#小页面设计
setting=tk.Tk()

delta_t =500  #定义循环速度为1ms

def finish():
    global delta_t #计算循环的速度
    print("初始化参数完成")
    #初始化
    electron_=electron(0,0,1,1,0,0)   #x,y,m,q,v_x,v_y
    E_=E(1,1)
         #显示页面
    top=tk.Tk()
    top.wm_title("参数")
    top.geometry('700x1000')
    show = Frame(top)
    show.grid(row=1,column=0)
    show2 = Frame(top)
    show2.grid(row=2,column=0)
    show3 = Frame(top)
    show3.grid(row=3,column=0)
    show4 = Frame(top)
    show4.grid(pady=40,column=1)
    show5 = Frame(top)
    show5.grid(pady=40,column=1)
    show6 = Frame(top)
    show6.grid(pady=40,column=1)
    show7 = Frame(top)
    show7.grid(pady=40,column=1)
    #开关按钮
    #按钮工具
    def start():
        global running
        running = True
    def stop():
        global running
        running = False
    def renewok():
        global renewyes
        renewyes = True
    def renewno():
        global renewyes
        renewyes = False
    def renewall():
        electron_.renewall()
        
    def change_delta_t(value):#改变运行速度
        global delta_t
        delta_t=(float(value))
        delta_t=int(delta_t)
    def change_electron_(value):
        electron_.m=float(value)/20

    def change_Ex_(value):
        E_.Ex=float(value)/50

    def change_Ey_(value):
        E_.Ey=float(value)/50


    start=Button(show,text="开         始",command=start)
    stop =Button(show,text='停         止',command=stop)
    renewok=Button(show2,text="尾迹   清除",command=renewok,anchor='ne')
    renewno=Button(show2,text='尾迹不清除',command=renewno,anchor='ne')
    renewall=Button(show3,text='尾迹全清除',command=renewall,anchor='ne')
    scale=tk.Scale(show4,label='运行快慢（等待时间）',from_=1
                   ,to=100,orient=tk.HORIZONTAL,
                   length=500,tickinterval=9,
                   command = change_delta_t)
    scale1=tk.Scale(show5,label='粒子质量',from_=1
                   ,to=100,orient=tk.HORIZONTAL,
                   length=500,tickinterval=9,
                   command = change_electron_)
    scale2=tk.Scale(show5,label='电场强度x轴',from_=-100
                   ,to=100,orient=tk.HORIZONTAL,
                   length=500,tickinterval=9,
                   command = change_Ex_)
    scale3=tk.Scale(show5,label='电场强度y轴',from_=-100
                   ,to=100,orient=tk.HORIZONTAL,
                   length=500,tickinterval=9,
                   command = change_Ey_)
    scale.grid()
    scale1.grid()
    scale2.grid()
    scale3.grid()
    start.grid()
    stop.grid()
    renewok.grid()
    renewno.grid()
    renewall.grid()

    #参数标签
    var =  tk.StringVar()	#保存为一个int类型的变量
    Label(top, text= "控制器" , font = (14)).place(x = 100,y = 0) 
    Label(top, text= "数据监测" , font = (14)).place(x = 300,y = 0) 

    var.set('0')	#设置初始值	
    Label(top, text= "带电粒子位置" , font = (14),fg = "green" ).place(x = 300,y = 20) 
    Label(top, text= "速度：" , font = (14),fg = "green" ).place(x = 310,y = 50) 

    var.set('0')	#设置初始值	
    Label(top, text= "电场强度" , font = (14),fg = "green" ).place(x = 300,y = 80) 

    var.set('0')	#设置初始值	
    Label(top, text= "运行时间" , font = (14),fg = "green" ).place(x = 300,y = 100) 

    def electron_move():#核心函数(封装)
    #观测坐标(改为三星中心)
        global observation_max,delta_t
        #axis_x=np.mean(electron_.x[-1])
        #axis_y=np.mean(electron_.y[-1])
        axis_x=observation_max
        axis_y=observation_max
        plt.clf()
        #plt.axis([axis_x-observation_max, axis_x+observation_max, axis_y-observation_max,  axis_y+observation_max])
        plt.axis([0, observation_max, 0, observation_max])
        plt.plot(electron_.x[-1], electron_.y[-1], 'og',markersize=electron_.m*5)  # 默认密度相同，质量越大的，球面积越大。视线范围越宽，球看起来越小。
        plt.plot(electron_.x, electron_.y, '-g')  # 画轨迹
        plt.pause(0.001)
        top.update()
        if running:
            #axis_x=np.mean(electron_.x[-1])
            #axis_y=np.mean(electron_.y[-1])
            #while True:
            #    if np.abs(electron_.x[-1]-axis_x) > observation_max or  np.abs(electron_.y[-1]-axis_y) > observation_max :
            #        observation_max = observation_max * 2  
                #有一个物体超出视线时，视线范围翻倍
            #    elif np.abs(electron_.x[-1]-axis_x) < observation_max/10 and np.abs(electron_.y[-1]-axis_y)< observation_max/10 :
            #        observation_max = observation_max / 2   # 所有物体都在的视线的10分之一内，视线范围减半
            #    else:
            #       break
            plt.clf()
            #plt.axis([axis_x-observation_max, axis_x+observation_max, axis_y-observation_max,  axis_y+observation_max])
            plt.axis([0,observation_max,0, observation_max])
            plt.plot(electron_.x[-1], electron_.y[-1], 'og',markersize=electron_.m*5)  # 默认密度相同，质量越大的，球面积越大。视线范围越宽，球看起来越小。
   #/observation_max
            plt.plot(electron_.x, electron_.y, '-g')  # 画轨迹
   
            plt.pause(0.001)
        
            #每一轮，都是相对于三星上一个状态的轮回
            electron_.situation(E_.Ex,E_.Ey)

            if renewyes:
                electron_.renewxy()

            #参数显示
            var.set(str(round(electron_.x[-1],1))+','+str(round(electron_.y[-1],1))) 
            Label(top, text= str(var.get()+'     ') , font = (14),fg = "green" ).place(x = 440,y = 20) 


            var.set(str(round(electron_.v_x,1))+','+str(round(electron_.v_y,1))) 
            Label(top, text= str(var.get()+'   ') , font = (14),fg = "green" ).place(x = 460,y = 50) 

            var.set(str(round(E_.Ex,1))+','+str(round(E_.Ey,1))) 
            Label(top, text= str(var.get()+'   ') , font = (14),fg = "green" ).place(x = 460,y = 80) 

            var.set(str(round(electron_.t,1)))
            Label(top, text= str(var.get()+'   ') , font = (14),fg = "green" ).place(x = 460,y = 100) 

        top.after(delta_t,electron_move)#每1ms后调用函数一次（闭包）
      
    top.after(1,electron_move)#这里只会调用一次，上面那个是形成的闭包
    top.mainloop()

button = tk.Button(setting,text='确定所有更改',command=finish).pack()

setting.mainloop()

    
