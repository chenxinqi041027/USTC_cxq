
import math
import numpy as np
import matplotlib.pyplot as plt
from itertools import count
from mpl_toolkits.mplot3d import Axes3D

#物理学参数
q=1  #1C
B=1  #1T
m=1  #1g
w=q*B/m
E=1  #1V/m

x_track = np.zeros((1, 3))
x_track_s = np.array([.0,.0,.0])
t = 0
def gen_path(): # 生成螺旋
    global x_track_s,x_track,t
    t += 0.1
    x = E/B*t-1/w*(math.cos(w*t)-1)
    y = 1/w*math.sin(w*t)
    x_track_s +=[x,y,0.1]
    x_track = np.append(x_track, [x_track_s],axis=0)
    return x_track

ax = plt.axes(projection = '3d')
ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_title('3d_mobile_obs')
#ax.set_xlim([0,70])
#ax.set_ylim([-60,-70])

plt.grid(True)
plt.ion() 

for t in count():
    if t == 20:
        break
    # plt.cla() # 每次清空画布，所以就不会有前序的效果
    ax.plot3D(x_track[:, 0], x_track[:, 1], x_track[:, 2], 'blue')
    x_track = gen_path()
    plt.pause(0.001)

