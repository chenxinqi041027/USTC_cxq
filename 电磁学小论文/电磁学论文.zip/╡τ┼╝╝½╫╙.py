import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
#直接根据电场公式绘图
#E=kQq/r2
def E(q,r,x,y):
    #返回电场矢量,r为矢量式
    r3=np.hypot(x-r[0],y-r[1])**3
    return q*(x-r[0])/r3,q*(y-r[1])/r3

#建立坐标格
nx, ny = 64, 64
x = np.linspace(-2, 2, nx)
y = np.linspace(-2, 2, ny)
X, Y = np.meshgrid(x, y)

#定义电荷
nq=2      #电荷数量
charges=[]
for i in range(nq):
    if i % 2 == 0:
        q = 1
    else:
        q = -1
    charges.append((1,(q*0.5,0)))
  #带有正1C在-0.5，0位置上的电荷
  #带有负1C在0.5，0位置上的电荷

#生成场强
Ex, Ey = np.zeros((ny, nx)), np.zeros((ny, nx))
for charge in charges:
    ex, ey = E(*charge, x=X, y=Y)
    Ex += ex
    Ey += ey

#画布设置
fig = plt.figure()
ax = fig.add_subplot(111)

# 
color = 2 * np.log(np.hypot(Ex, Ey))
ax.streamplot(x, y, Ex, Ey, color=color, linewidth=1, cmap=plt.cm.inferno,
              density=1, arrowstyle='->', arrowsize=0.5)

#
charge_colors = {True: '#aa0000', False: '#0000aa'}
for q, pos in charges:
    ax.add_artist(Circle(pos, 0.05, color=charge_colors[q > 0]))

ax.set_xlabel('$x$')
ax.set_ylabel('$y$')
ax.set_xlim(-2, 2)
ax.set_ylim(-2, 2)
ax.set_aspect('equal')
plt.show()
