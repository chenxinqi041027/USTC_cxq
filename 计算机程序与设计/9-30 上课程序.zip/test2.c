#include<stdio.h>

void main()
{
    int a = 3;
    int i = 5;
    printf("a's address is %d\n", &a);
    printf("a's address is %p\n", &a);
    printf("i = %d %d %d\n", i, i++, ++i);

    i = 2;
    int b[3] = {1, 2, 3, 4};
    b[i] = i++; //b[2]=2
    printf("%d %d\n", b[i], i);
    return;
}