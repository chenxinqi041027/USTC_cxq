#include<stdio.h>

int main() {
	int a;
	printf("%d\n",3>2);
	printf("%d\n",3>2>1);
	printf("%d\n",a=3>2>1);
	return 0; 
}
