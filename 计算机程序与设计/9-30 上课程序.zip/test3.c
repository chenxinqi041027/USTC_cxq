#include<stdio.h>

void main()
{
    int num1, num2, num3;
    num1 = 3;
    num2 = 7;
    num3 = 5;
    int max;
    if(num1 > num2)
        max = num1;
    else
        max = num2;

    if(max < num3)        
        max = num3;
    printf("max = %d\n", max);
}