#include<stdio.h>

void main()
{
    int num1, num2, num3;
    num1 = 3;
    num2 = 7;
    num3 = 5;
    int max = num1;
    if(num2 > max)
        max = num2;
    if(num3 > max)        
        max = num3;
    printf("max = %d\n", max);
}