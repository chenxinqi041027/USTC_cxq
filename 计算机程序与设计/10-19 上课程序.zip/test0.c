#include<stdio.h>

void main()
{
//    int a1, a2, a3, a4, a5, a6, a7, a8;
    int a[8] = {10, 19, 2022, 1958, 8348, 96, 1450, 1};
    for(int i1 = 0; i1 < 8; i1++)
    for(int i2 = 0; i2 < 8; i2++)
    for(int i3 = 0; i3 < 8; i3++)
    for(int i4 = 0; i4 < 8; i4++)
    for(int i5 = 0; i5 < 8; i5++)
    for(int i6 = 0; i6 < 8; i6++)
    for(int i7 = 0; i7 < 8; i7++)
    for(int i8 = 0; i8 < 8; i8++)
    {
        if(i1 != i2 && i1 != i3 && i1 != i4 && i1 != i5 && i1 != i6 && i1 != i7 && i1 != i8 
        && i2 != i3 && i2 != i4 && i2 != i5 && i2 != i6 && i2 != i7 && i2 != i8
        && i3 != i4 && i3 != i5 && i3 != i6 && i3 != i7 && i3 != i8
        && i4 != i5 && i4 != i6 && i4 != i7 && i4 != i8
        && i5 != i6 && i5 != i7 && i5 != i8
        && i6 != i7 && i6 != i8
        && i7 != i8)
        {
            if(a[i1] < a[i2] && a[i2] < a[i3] &&a[i3] < a[i4] &&a[i4] < a[i5] &&a[i5] < a[i6] 
               && a[i6] < a[i7] && a[i7] < a[i8])
               printf("%d %d %d %d %d %d %d %d", a[i1], a[i2], a[i3], a[i4], a[i5], a[i6], a[i7], a[i8]);
        }

    }
    return;
}