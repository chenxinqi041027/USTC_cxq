#include<stdio.h>

void main()
{
    int a[3] = {1958, 8348, 1450};

    int pivot = 10000;
    int pivot_index = -1;
    if(a[0] < pivot)
    {    
        pivot = a[0];
        pivot_index = 0;
    }
    if(a[1] < pivot)
    {    
        pivot = a[1];
        pivot_index = 1;
    }
    if(a[2] < pivot)
    {
        pivot = a[2];
        pivot_index = 2;
    } 
    if(pivot_index != 0)
    {
        int temp;
        temp = a[0];
        a[0] = a[pivot_index];
        a[pivot_index] = temp;
    }


    pivot = 10000;
    pivot_index = -1;
    if(a[1] < pivot)
    {    
        pivot = a[1];
        pivot_index = 1;
    }
    if(a[2] < pivot)
    {    
        pivot = a[2];
        pivot_index = 2;
    }
    if(pivot!=a[1]) 
    {
        int temp;
        temp = a[1];
        a[1] = a[pivot_index];
        a[pivot_index] = temp;
    }   

    printf("%d %d %d\n", a[0], a[1], a[2]);

    return;
}