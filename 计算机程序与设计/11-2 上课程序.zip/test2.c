#include<stdio.h>

int f(int a)	
{
	int b=0;
	static int c=0;  //只初始化一次
	b=b+1;
	c++;
	return(c);
}

void main()	{
	int a=2;
	for(int i=0;i<3;i++)
		printf("f(int a) has been called \t%d times\n", f(i));
}
