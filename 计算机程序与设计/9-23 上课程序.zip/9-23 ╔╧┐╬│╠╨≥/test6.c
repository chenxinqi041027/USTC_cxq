#include<stdio.h>

void main()
{

   for(int i=0; i<=100; i++)
   {
        printf("test2 before scan\n");
        printf("i = %d\?", i);
   }

    printf("test1 harder");

   return;
}