#include<stdio.h>
int main() {
	float data[4];
	float sum=0, ave;//同类型的变量可以一起定义
	int i;  
	for(i=0;i<4;i++)
	{
		scanf("%f", &data[i]);
		sum=sum+data[i]; 
	}
	ave=sum/4;  //增加输入数据的时候别忘记改这里
	printf("The ave is %.2f",ave);
  //%.2f表示输出时只保留小数点后2位 
}
