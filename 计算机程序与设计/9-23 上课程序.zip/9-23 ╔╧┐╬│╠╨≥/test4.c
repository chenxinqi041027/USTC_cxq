#include<stdio.h>

void main()
{
    int i;
    //int j;
    for (i = 0; i < 100; i++)
    {
        if(i % 3 == 0)
           printf ("i = %d\n", i);
        if(i % 10 == 3)
            printf ("i = %d\n", i);
        if(i/10 == 3)
            printf ("i = %d\n", i);
    }
    return;
}