#include<stdio.h>

void main()
{
    int i;
    int j = 0;
    for (i = 0; i < 100; i++)
    {
        if(i % 3 == 0 || i % 10 == 3 || i/10 == 3)
        {

        j++;    
                   printf ("i = %d ", i);
        }
        if(j % 5 == 0)
            printf("\n");

    }
    return;
}