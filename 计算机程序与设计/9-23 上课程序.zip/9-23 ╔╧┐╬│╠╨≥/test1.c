#include<stdio.h>
int main() {
	float data[8] = {3.2,2.3,2.2,2.4,2,3.0,2.9,2.8};
	float sum = 0; //sum用于求和计算，初值赋为0 
	float ave; //平均值放这个变量里 
	int i; //循环控制变量 
	for(i = 0;i < 8;i++) //计数循环用for语句更清晰
	{
		sum = sum + data[i];
	//累加求和，data[i]是数组元素，从0开始 
	}
	ave = sum/8; //计算平均值 
	printf("The average is %f",ave); 
}
