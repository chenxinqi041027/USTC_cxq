#include<stdio.h>

void main()
{
    int i;
    for (i = 0; i < 20; i++)
    {
        if(i % 3 == 0)
          printf ("i = %d\n", i);
    }
    return;
}