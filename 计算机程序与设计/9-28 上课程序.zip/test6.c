#include<stdio.h>
int main() {
	short int i;
    short int j = i-1;
	for(i=0;i>=0;i++); //好奇怪的循环语句
	printf("%d ",i); //循环结束再打印
    printf("%d ",j); //循环结束再打印

}
