#include<stdio.h>

void main()
{
    float a = 1.71353;
    printf("%.3f\n", a);

    return;
}