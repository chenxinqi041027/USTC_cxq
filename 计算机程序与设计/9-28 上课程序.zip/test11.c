#include<stdio.h>

int main() {
	char c,i;
	for(i=0;i<5;i++)
	{
		c=getchar();
		if(c<='z' && c >= 'a') 
		   putchar(c-'a'+'A');
	}
	return 0; 
}
