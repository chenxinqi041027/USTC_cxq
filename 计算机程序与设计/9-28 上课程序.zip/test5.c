#include<stdio.h>
#include<math.h>

void main()
{
    long long int i;
    i = pow(2, 31) - 1;
    printf("MAX of int is: %d\n", i);
    return;
}