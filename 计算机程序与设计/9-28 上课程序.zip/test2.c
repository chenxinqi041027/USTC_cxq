#include <stdio.h>

void main()
{
  int i;
  i = 3;
  printf("int %d ", sizeof(int));
  printf("int %d\n", sizeof(i));

  float a;
  printf("float %d ", sizeof(float));
  printf("float %d\n", sizeof(a));

  double d;
  printf("double %d ", sizeof(double));
  printf("double %d\n", sizeof(d));

  char c;
  printf("char %d ", sizeof(char));
  printf("char %d\n", sizeof(c));

  
  return;
}