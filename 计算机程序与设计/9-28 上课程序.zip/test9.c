#include<stdio.h>
int main() {
	float x1=0.1;
	double x2=0.1;
	if((x1-x2)<1e-6) printf(“x1与x2相等”);//不完美
	else printf("x1与x2不相等");
} //但够用就好
