#include<stdio.h>
int main() {

	short int i;
	for(i=0;i>=0;i++)//循环直至i<0结束，这科学吗？！
		printf("%d ",i); //边循环边打印，无穷无尽
	short j = i;
        printf("%d ",j); //循环结束再打印
    
}
