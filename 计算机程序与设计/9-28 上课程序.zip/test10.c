#include<stdio.h>
#include<conio.h> //getche函数在这里说明
int main() {
	char c,i;
	for(i=0;i<15;i++)
	{
		c=getche();
		if(c>='a'&&c<='z') putchar(c-'a'+'A');
	}
	return 0; 
}
