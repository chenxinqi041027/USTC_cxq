#include<stdio.h>
#include<string.h>

void main()
{
    char str1[] = "Original String";
    char str2[] = "New String";

    strcpy(str2, str1);
    printf("str1: %s\n", str1);
    printf("str2: %s\n", str2);
    return;
}