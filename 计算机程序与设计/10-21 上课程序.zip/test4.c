#include<stdio.h>

#define N 10

void main()
{
    int a[N];

    for(int i = 0; i < N; i++)
        scanf("%d", &a[i]);

    for(int i = 0; i < N; i++)
        printf("a[%d]=%d ", i, a[i]);
    
    printf("\n");

    int tmp;
    
    for(int i = 0; i < N/2; i++)
    {
        tmp = a[i];
        a[i] = a[N-1-i];
        a[N-1-i] = tmp;
    }

    for(int i = 0; i < N; i++)
        printf("a[%d]=%d ", i, a[i]);
    return;
}