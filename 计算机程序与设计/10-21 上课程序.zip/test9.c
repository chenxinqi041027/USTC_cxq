#include<stdio.h>
#include<string.h>

void main()
{
    char str1[] = "Beijing";
    char str2[] = "Hefei";
    printf("%s\n", str1);
    printf("%s\n", str2);
    printf("%u\n", sizeof(str1));    
    printf("%u\n", sizeof(str2));
    printf("%u\n", strlen(str1));    
    printf("%u\n", strlen(str2)); 

    strcpy(str2, str1);

    printf("%s\n", str1); //    char str1[] = "Beijing";
    printf("%s\n", str2); //    char str2[] = "Hefei";
    return;
}