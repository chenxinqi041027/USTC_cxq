#include<stdio.h>

#define N 8

void main()
{
    int a[N];
    for(int i = 0; i < N; i++)
        scanf("%d", &a[i]);

    for(int i = 0; i < N; i++)
        printf("%d ", a[i]);
    putchar('\n');

    int pivot = -10000;
    for(int i = 0; i < N; i++)
    {
        if(pivot < a[i])
            pivot = a[i];
    }
    printf("Max value of a[N] is %5d\n", pivot);
    return;
}