#include<stdio.h>

void main()
{
    int i = 3;
    printf("i = %d\n\n\n", i);  //; ；
    int a, b;
    a = 1;
    b = 1;
    int c;
    c = a + b;
    printf("c = %d\n", c);
    
    c = 6;
    printf("before swap: a = %d, c = %d\n", a, c);

    int tmp;
    tmp=a;
    a = c;
    c = tmp;

    printf("after swap: a = %d, c = %d\n", a, c);

    float j = 3.5;
    printf("%f", j);
    printf("\t %lf", j);

    /*
    printf("hello world!");
    */

    return;
}