#include<stdio.h>
#include<string.h>

void main()
{
    char s1[32]= "destination";
    char s2[32]= "src";
    strcpy( s1, s2);   //s1 → ”src”
    puts(s1);
    puts(s2);
    for(int i = 0; i < 32; i++)
        putchar(s1[i]);
    return;
}