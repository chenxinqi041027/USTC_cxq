#include<stdio.h>
#include<string.h>
#include<stdio.h>

void main()
{
    char s1[32]= "computer";
    char s2[32]= "compare";
    puts(s1);
    puts(s2);
    if(strcmp(s1, s2)==0)
        printf("s1 and s2 are the same\n");
    else   
        printf("s1 and s2 are NOT the same\n");

    char s3[32]= "computer";
    if(strcmp(s1, s3)==0)
        printf("s1 and s3  are the same\n");
    else   
        printf("s1 and s3 are NOT the same\n");

    return;
}