#include <stdlib.h> //标准实用函数库
#include<stdio.h>

int main()  {
    double val;
    val = atof("3.1415926");
    //把字符串转换为一个double型浮点数

    /*double 
    scanf %lf
    printf %f*/

    printf("%f", val);
    return 0;
}
