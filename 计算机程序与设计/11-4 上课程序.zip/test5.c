#include<stdio.h>
#include<string.h>

void main()
{
    char s1[32]= "dest";
    char s2[32]= "src";
    strcat( s1, s2); //s1 → "destsrc"

    puts(s1);
    puts(s2);
    return;
}