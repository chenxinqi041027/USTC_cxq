#include<stdio.h>

void main()
{
    printf("嘻嘻!\n"); //打印中文

    return;
}