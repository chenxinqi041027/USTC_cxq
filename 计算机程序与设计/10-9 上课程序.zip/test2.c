#include <stdio.h> //用switch计算满绩5的GPA

int main(){
	int score;scanf("%d",&score);
	if(score>=60&&score<=100){
	  switch((score-50)/10) {
	  case 5:
	  case 4:printf("GPA%.1f--A",(score-50)/10.0);
		   break;
	  case 3:if(score>=85) 
		     printf("GPA=%.1f--A",(score-50)/10.0);
		   else
		     printf("GPA=%.1f--B",(score-50)/10.0); 
		   break;
	  case 2:printf("GPA=%.1f--B",(score-50)/10.0);
		   break;
	  case 1:printf("GPA=%.1f--C",(score-50)/10.0); 
	  }
	} 
	else if(score>=0&&score<60)  printf("GPA=0--D"); 
      else printf("out of range");  //不合法成绩
}
