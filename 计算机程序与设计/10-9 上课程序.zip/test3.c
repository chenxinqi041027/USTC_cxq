#include<stdio.h>
int main()
{
	int score; 
	scanf("%d", &score);
	if(score >= 60 && score <= 100)
	{
		int m = (score - 50) / 10;
		if(m == 5 || m == 4 || (m == 3 && score >= 85)) 
		{
			 printf("GPA = %.1f -- A\n", (score - 50) / 10.0);
		}
		   
		else if(m == 3 || m == 2) 
		{
			printf("GPA = %.1f -- B\n", (score - 50) / 10.0);
		}
		    
		else if(m == 1) 
		{
			printf("GPA = %.1f -- C\n", (score - 50) / 10.0);
	    }
	}
		    
	else if(score >= 0 && score <= 60)
	{
		 printf("GPA = 0 -- D\n");
	} 
	       
	else printf("Out of Range\n"); 
    
	return 0;
}
