#include <stdio.h> //求一元二次方程ax2+bx+c=0的解(a≠0)
#include <math.h> //fabs函数在这里
int main(){
   float a,b,c,disc,x1,x2,p,q;
   scanf("%f%f%f", &a, &b, &c); 
   disc=b*b-4*a*c;
   if(fabs(disc)<=1e-6) //fabs()：求绝对值库函数
	printf("x1=x2=%7.2f\n",-b/(2*a));//两个实根相等
   else{
	if(disc>1e-6){
	   x1=(-b+sqrt(disc))/(2*a);//求两个不相等的实根
	   x2=(-b-sqrt(disc))/(2*a);
         printf("x1=%7.2f,x2=%7.2f\n", x1, x2);}
	else {
	   p=-b/(2*a); //求两个共轭复根的实部
	   q=sqrt(fabs(disc))/(2*a); //求共轭复根的虚部
	   printf("x1=%7.2f+%7.2fi\n",p,q); //输出共轭复根
         printf("x2=%7.2f - %7.2f i\n", p, q);}
	} //else总是与在它上面、距它最近、且尚未匹配的if配对
}
