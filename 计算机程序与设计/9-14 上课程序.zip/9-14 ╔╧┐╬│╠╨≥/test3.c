#include<stdio.h> //standard input & output head file

void main()
{
    //int i = 3;
    //printf("i = %d", i);

    // // // //i = 3
    // j = 5
    /* i = 3 
    此处省略
    */
    //float a1 = 1.5;
    //printf("a1 = %f", a1);

    double _ustc1958 = 1.5;
    printf("_ustc1958 = %lf\n", _ustc1958);

    char a = 'x';
    printf("a = %c\n", a);

    char a1 = '*';
    printf("a1 = %c\n", a1);

    printf("  **  \n");
    printf(" **** \n");
    printf("******\n");
    printf(" **** \n");
    printf("  **  \n");


    return;
}