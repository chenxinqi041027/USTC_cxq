#include<stdio.h>

void main()
{
    int i;
    int j;
    //printf("_ustc1958 = %lf\n", _ustc1958);
    scanf("i=%d,%d", &i,&j);
    printf("i = %d I am here", i);
    printf("j = %d j is here", j);
    return;
}