#include <stdio.h>

int main()
{
	int a,b,c,d;
    scanf("%d", &a);
    printf("a=%d\n", a);
}