#include<stdio.h>
int main()
{
	int weight;
	float height;
	scanf("%d", &weight);
	scanf("%f", &height);
	printf("%d\n", weight); 
// '\n'是换行符，用于分隔两个输出，删掉后输出会糊成一团
	printf("%f", height);
} 