#include <stdio.h> //header file

void main()
{
//    char a[4] = {'h', 'e', 'l', '\0'};
    char a[4] = {"hel"};
    printf("%c%c%c\n", a[0], a[1], a[2]);

    return;

}

