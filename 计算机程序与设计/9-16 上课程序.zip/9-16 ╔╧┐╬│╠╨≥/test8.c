#include<stdio.h>
int main()
{
	int bmi;
	int weight;
	float height;
	scanf("%d",&weight);
	scanf("%f",&height);
	bmi = weight/height/height;	 //计算bmi的语句
	printf("%d",bmi);      //在屏幕上打印bmi值
}
