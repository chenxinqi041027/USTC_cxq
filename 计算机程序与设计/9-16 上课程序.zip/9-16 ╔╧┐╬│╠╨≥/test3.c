#include <stdio.h> //header file

void main()
{

    /*char a = 'Z';
    printf("ascii = %d\n", a);
    printf("char = %c\n", a);*/

    char a = 'Z';
    printf("char has %d Byte\n", sizeof(a));
    int b;
    short int b1;
    float c;
    double d;
    printf("short int has %d Byte\n", sizeof(b1));
    printf("int has %d Byte\n", sizeof(b));
    printf("float has %d Byte\n", sizeof(c));
    printf("double has %d Byte\n", sizeof(d));

    float height;
    int weight;
    float BMI;
    weight = 65; //程序规范
    height = 1.73;
    printf("height = %d\n", height);
    BMI = weight / (height * height);
    printf("BMI = %d\n", BMI);

    return;

}

