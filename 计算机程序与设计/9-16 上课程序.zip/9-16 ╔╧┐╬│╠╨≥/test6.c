#include <stdio.h> //header file

void main()
{
    int i;
    //printf("a =%d\n", i);

    scanf("a =%d", &i);
    printf("a =%d\n", i);
    return;


}