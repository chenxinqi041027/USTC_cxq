#include <stdio.h> //header file

void main()
{
    char a[4];
    a[0] = 'h';
    a[1] = 'e';
    a[2] = 'l';
    a[3] = '\0';
    printf("%c%c%c\n", a[0], a[1], a[2]);

    return;

}

